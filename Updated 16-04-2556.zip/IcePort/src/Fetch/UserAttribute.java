package Fetch;


public class UserAttribute {
	public String uid;
	public String username;
	public int type;
	public String ip;
	public int port;
	public int pid;
	public int x;
	public int y;
	
	public UserAttribute(String uid){
		this.uid = uid;
	}
	
}
