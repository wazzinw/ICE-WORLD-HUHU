package Login;

public class NameCheck {
	String name;
	int cnt;
	NameCheck(){
		this.name = "";
		cnt =0;
	}
	NameCheck(String name){
		this.name = name;
		cnt =1;
	}
	
	
}
