package Fetch;

import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FetchStates{
	public String weatherCondition = "";
	JSONParser json = new JSONParser();
	LinkedList<UserAttribute> user;
	 ContainerFactory containerFactory = new ContainerFactory() {
		    public List creatArrayContainer() { return new LinkedList(); } 
		    public Map createObjectContainer() { return new LinkedHashMap(); }

	 };
	 
	public FetchStates(LinkedList<UserAttribute> user){
		this.user = user;
		this.fetch();
	}
	
	public void fetch(){
		user.clear();
		String inputLine = "";
		try{
		    URL url = new URL(" http://iceworld.sls-atl.com/api/&cmd=states");
		    URLConnection urlc = url.openConnection();
		    BufferedReader in = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
		    String buffs;
		    while ((buffs = in.readLine()) != null){
		        inputLine = inputLine + buffs;
		    }
		    in.close();
		 }catch (Exception e){
		     System.err.println("Error");
		 }
		try {
			Map jsonMap = (Map)this.json.parse(inputLine, this.containerFactory);
			Map jsonData = (Map)jsonMap.get("data");
			Map weather = (Map)jsonData.get("weather");
			Map iceTizen = (Map)jsonData.get("icetizen");
			int size = iceTizen.size();
			Object [] key = iceTizen.keySet().toArray();
			for(int i=0 ; i<size ; i++){
				UserAttribute n = new UserAttribute((String) key[i]);
				Map jsonUserDetail = (Map)iceTizen.get(key[i]);
				Map jsonUser = (Map)jsonUserDetail.get("user");
				Map lastKnown = (Map)jsonUserDetail.get("last_known_destination");
				n.username = (String) jsonUser.get("username");
				//System.out.println(n.username);
				n.type = Integer.parseInt(jsonUser.get("type").toString());
				n.ip = (String) jsonUser.get("ip");
				n.port = Integer.parseInt(jsonUser.get("port").toString());
				n.pid = Integer.parseInt(jsonUser.get("pid").toString());
				String d = lastKnown.get("position").toString();
				n.x = Integer.parseInt(d.substring(1, d.indexOf(',')));
				n.y = Integer.parseInt(d.substring(d.indexOf(',')+1,d.indexOf(')')));
				//System.out.println(n.x+" "+n.y);
				user.add(n);
			}
			weatherCondition = (String) weather.get("condition");
				
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
			
	}
	
	public static void main(String [] args){
		LinkedList<UserAttribute> user = new LinkedList<UserAttribute>();
		new FetchStates(user);
	}
}
