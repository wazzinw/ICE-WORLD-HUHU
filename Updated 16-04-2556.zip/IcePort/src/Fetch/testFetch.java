package Fetch;

import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;


public class testFetch {
	//static Fetching s;
	
	
	public static void main(String[]a){
		
		//METHUS FETCH	
		/*LinkedList<UserAttribute> user = new LinkedList<UserAttribute>();
		FetchStates s = new FetchStates(user);
		System.out.println(s.weatherCondition);
		System.out.println(user.get(0).uid);
		System.out.println(user.get(1).username);*/
		
		//Arm
		CountDownLatch latch = new CountDownLatch(1);
		Fetching s = new Fetching();
		Thread c = new Thread(new FetchTask(s,2000,latch));
		
		c.start();
		
		try{
            latch.await();  //main thread is waiting on CountDownLatch to finish
            System.out.println("All services are up, Application is starting now");
       }catch(InterruptedException ie){
           System.out.println("Freak");
       }
		System.out.println("=============================");
		System.out.println("Data Received"); 
		System.out.println("=============================");
		System.out.println(s.weather);
		System.out.println(s.tizen.size());
		//System.out.println(null.toString());
		}
		
		
	}

