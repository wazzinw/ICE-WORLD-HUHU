package ICEPort;
import iceworld.given.IcetizenLook;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.*;

import Fetch.Fetching;
import Login.Customize;
import Login.test1;


public class GridProjection extends JPanel{
	final int row = 100, col = 100;
	private int diaX, diaY, gridX, gridY;
	private int mouseX,mouseY;
	private int [] xCo,yCo;
	private int width = 800,height = 500;
	private int posX = 385,posY = 375,imageW = 28,imageH = 32;
	//int X,Y;
	Point d = new Point();
	Customize c;
	public GridProjection(){
		this.setSize(width, height);
		zoom(1);
		gridX = -1; 
		gridY = -1;
		try {
			c = new Customize();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		c.setVisible(false);



		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				mouseX = e.getX();
				mouseY = e.getY();
				gridX = (50*mouseX+100*mouseY-50*diaY)/diaY;
				gridY = (100*mouseY-50*mouseX+50*diaY)/diaY;


				System.out.println("Grid: "+gridX+" , "+gridY);

				if(gridX>-1&&gridY>-1 && gridX<101&&gridY<101)
				{   
					walk(gridX,gridY);
					System.out.println("Position: "+posX+" , "+posY);
				}
				repaint();
			}

		});


	}

	public void zoom(double i){
		width = (int) (width*i);
		height = (int) (height*i);
		this.setPreferredSize(new Dimension(width,height));
		diaX = (int)(800*i);
		diaY = diaX/2;
		xCo = new int []{0,diaX/2,diaX,diaX/2};
		yCo = new int []{diaY/2,0,diaY/2,diaY};
		posX = (int) (posX*i);
		posY = (int) (posY*i);
		imageW*= i;
		imageH*=i;
		repaint();
	}


	public void paintComponent(Graphics g){
		int startX=0, startY=0;
		g.setColor(new Color(192,192,192));
		g.fillRect(0, 0, width, height);

		g.setColor(new Color(0,204,102));
		g.fillPolygon(xCo,yCo,4);
		if(gridX>-1&&gridY>-1 && gridX<101&&gridY<101){
			startX = diaY*(gridX-gridY+100)/100;
			startY = diaY*(gridX+gridY)/200;
			int [] gridXCo = new int []{startX,startX+diaX/200,startX,startX-diaX/200};
			int [] gridYCO = new int []{startY,startY+diaY/200,startY+diaY/100,startY+diaY/200};
			g.setColor(Color.RED);
			g.fillPolygon(gridXCo, gridYCO, 4);
		}



		d.x = posX;d.y=posY;
		drawWeapon(g,"B002",d);
		drawHead(g,"H008",d);
		drawBody(g,"S019",d);
		drawShirt(g,"W046",d);
		IcetizenLook look = new IcetizenLook();
		Point s = new Point();
		String type = "";
		String username ="";
		for(int i =0;i<ICEFrame.s.tizen.size();i++){
			s  = ICEFrame.s.tizen.get(i).position;
			s = getGridCo(s.x,s.y);
			look =ICEFrame.s.tizen.get(i).getIcetizenLook();
			type = ICEFrame.s.tizen.get(i).gettype();
			username = ICEFrame.s.tizen.get(i).getUsername();
			if(type.equals("0")){
				showAlien(g,s,username);
			}else showCitizen(g,s,look,username);	
			
			
		}

	}
	private void showAlien(Graphics g, Point location,String username) {
		Image  alienImage = Toolkit.getDefaultToolkit().getImage("alien3.gif");	
		//Image img = alienImage.getScaledInstance(imageW, imageH, Image.SCALE_SMOOTH);
		g.drawImage(alienImage,location.x,location.y,null);
		g.setColor(Color.red);
		g.drawString(username, location.x-3, location.y-5);
	}

	public void showCitizen(Graphics g,Point p,IcetizenLook look,String username){
		drawWeapon(g,look.gidW,p);
		drawHead(g,look.gidH,p);
		drawBody(g,look.gidB,p);
		drawShirt(g,look.gidS,p);
		g.setColor(Color.red);
		g.drawString(username, p.x-3, p.y-5);
		


	}
	public Point getGridCo(int x,int y){
		int a = diaY*(x-y+100)/100;
		int b = diaY*(x+y)/200;
		return new Point(a,b);

	}
	public void walk(int x,int y){
		//test1.immigration.walk(x, y);
		posX = mouseX-imageW+diaX/200;
		posY = mouseY-imageH+diaY/200;
		repaint();



	}
	public void drawBody(Graphics g,String bodyCode,Point location){
		BufferedImage bodyImg = null;
		try {
			bodyImg = (BufferedImage) c.getBodyImage(c.getBodyIdx(bodyCode));
		} catch (IOException e) {
			System.out.println("Fudge");
		}
		Image a = bodyImg.getScaledInstance(imageW, imageH, Image.SCALE_SMOOTH);
		g.drawImage(a,location.x,location.y,null);


	}

	public void drawHead(Graphics g,String headCode,Point location){
		BufferedImage headImg = null;
		try {
			headImg = (BufferedImage) c.getHeadImage(c.getHeadIdx(headCode));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Fudge");
		}
		Image b = headImg.getScaledInstance(imageW, imageH, Image.SCALE_SMOOTH);
		g.drawImage(b,location.x,location.y,null);



	}
	public void drawShirt(Graphics g,String shirtCode,Point location){
		BufferedImage shirtImg = null;
		try {
			shirtImg = (BufferedImage) c.getShirtImage(c.getShirtIdx(shirtCode));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Fudge");
		}
		Image c = shirtImg.getScaledInstance(imageW, imageH, Image.SCALE_SMOOTH);
		g.drawImage(c,location.x,location.y,null);





	}


	public void drawWeapon(Graphics g,String weaponCode,Point location){
		BufferedImage weaponImg = null;
		try {
			weaponImg = (BufferedImage) c.getWeaponImage(c.getWeaponIdx(weaponCode));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Fudge");
		}
		Image d = weaponImg.getScaledInstance(imageW, imageH, Image.SCALE_SMOOTH);
		g.drawImage(d,location.x,location.y,null);

	}


}
