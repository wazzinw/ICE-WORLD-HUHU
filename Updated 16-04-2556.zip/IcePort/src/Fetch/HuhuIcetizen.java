package Fetch;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import iceworld.given.IcetizenLook;

public class HuhuIcetizen implements iceworld.given.MyIcetizen{
	
	IcetizenLook look = new IcetizenLook();
	int listeningPort;
	
	//action

	String uid;
	String username;
	String type;
	String ip;
	String port;
	int portID;
	public Point position;
	
	static JSONParser json = new JSONParser();
	 static ContainerFactory containerFactory = new ContainerFactory() {
		    public List creatArrayContainer() { return new LinkedList(); } 
		    public Map createObjectContainer() { return new LinkedHashMap(); }

	 };
	
	
	

	

	public HuhuIcetizen(String uid, String username, String type, String ip, String port, String portID,Point position){
		this.uid=uid;
		this.username= username;
		this.type=type;
		this.ip=ip;
		this.port= port;
		this.portID = Integer.parseInt(portID);
		this.position=position;
		
	}

	public String getuid() {

		return uid;
	}

	@Override
	public String getUsername() {

		return username;
	}
	public String gettype() {

		return type;
	}
	public String getip() {

		return ip;
	}
	public String getport() {

		return port;
	}

	@Override
	public int getIcePortID() {

		return portID;
	}
	public Point getPosition() {

		return position;
	}


	
	///////////////////////////////
	@Override
	public IcetizenLook getIcetizenLook() {
		try {
			fetchString();
		} catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return look;
	}

	@Override
	public int getListeningPort() {

		return listeningPort;
	}



	
	///////////////////////////////////////
	@Override
	public void setIcePortID(int arg0) {

		portID = arg0;
	}

	@Override
	public void setIcetizenLook(IcetizenLook arg0) {
		look = arg0;

	}

	@Override
	public void setListeningPort(int arg0) {
		listeningPort = arg0;

	}

	@Override
	public void setUsername(String arg0) {
		username = arg0;

	}
	
	public void fetchString() throws org.json.simple.parser.ParseException{
		String inputLine = "";
		try
	    {
	      URL url = new URL("http://iceworld.sls-atl.com/api/&cmd=gresources&uid="+uid);
	      URLConnection urlc = url.openConnection();
	      BufferedReader in = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
	      String buffs;
	      while ((buffs = in.readLine()) != null)
	      {
	        inputLine = inputLine + buffs;
	      }
	      in.close();
	    }
	    catch (Exception e)
	    {
	      System.out.println("Error");
	    }
		List<Map> jsonData = null;
		try {
			Map jsonMap = (Map)json.parse(inputLine, containerFactory);
			jsonData = (List<Map>)jsonMap.get("data");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		look.gidH = ((String) jsonData.get(0).get("H")==null) ? "H008": (String) jsonData.get(0).get("H");
		look.gidB = ((String) jsonData.get(0).get("B")==null) ? "B001": (String) jsonData.get(0).get("B");
		look.gidW = ((String) jsonData.get(0).get("W")==null) ? "S019": (String) jsonData.get(0).get("W");
		look.gidS = ((String) jsonData.get(0).get("S")==null) ? "W050": (String) jsonData.get(0).get("S");
	}

}