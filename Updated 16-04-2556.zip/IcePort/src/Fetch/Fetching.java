package Fetch;
import iceworld.given.IcetizenLook;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import iceworld.given.ICEWorldImmigration;
import iceworld.given.IcetizenLook;

import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


public class Fetching extends Thread {

	URL myURL;
	String response;
	 public static LinkedList<HuhuIcetizen> tizen = new LinkedList<HuhuIcetizen>();
	LinkedList<HuhuIcetizen> actions = new LinkedList<HuhuIcetizen>();
	Set keys;
	Iterator i;
	Map uid;
	List<Map> look;
	Map json;
	Map jsonData;
	Map user;
	Map last_known_destination;
	Map action;
	
	
	String time;	
   public static String weather = "";
	String username;
	String ip;
	String type;
	String port;
	String pid;
	Point position;
	int x,y;
	
	IcetizenLook looks =new IcetizenLook();
	
	

	
	int count =0;
	JSONParser parser = new JSONParser();

	ContainerFactory containerFactory = new ContainerFactory() {
		public List creatArrayContainer() { return new LinkedList(); } 
		public Map createObjectContainer() { return new LinkedHashMap(); }

	};


	public void run(){
		//while(true){
		try
		{
			System.out.println("Fetch number "+count++);
			System.out.println("=============================");
			time = (String)((Map)this.parser.parse(getto("time"), this.containerFactory)).get("data");
			System.out.println("Time: "+time);
			json = (Map)this.parser.parse(getto("states"), this.containerFactory);
			jsonData = (Map)json.get("data");
			//json.entrySet().iterator();
			weather = (((Map)jsonData.get("weather")).get("condition").toString());
			System.out.println("Weather: "+weather);
			System.out.println("=============================");
			
			
			
//			keys =jsonData.keySet();
//			i = keys.iterator();			
//			while(i.hasNext()){
//				System.out.println((String)i.next());	
//			}
			//json  -status
			//		-Data  -- weather --- condition,Lastchange
			//			  -- icetizen --- 66,77 ---- user-----username,type,ip,port,pid
			//										 last_known_destination-----position,timestamp
		
		
			
			Map icet = (Map)jsonData.get("icetizen");
			keys = icet.keySet();
			i = keys.iterator();
			String g;
			
			while(i.hasNext()){
				g=(String)i.next();
				
				uid = (Map)icet.get(g);
				user = (Map)uid.get("user");
				last_known_destination = (Map)uid.get("last_known_destination");
				
				System.out.println(g);	
				username= user.get("username").toString();
				type= user.get("type").toString();
				ip= user.get("ip").toString().toString();
				port= user.get("port").toString();
				pid= user.get("pid").toString();
				
				String p;
				//System.out.println(last_known_destination.get("position").toString().equals(null));
				if(last_known_destination.get("position")==null) p = "(0,0)";
				else p = last_known_destination.get("position").toString();
				
				//p = (last_known_destination.get("position").toString().equals(null))
							//?"(0,0)":last_known_destination.get("position").toString();
				System.out.println(p);
				x = Integer.parseInt(p.substring(1, p.indexOf(',')));
				y = Integer.parseInt(p.substring(p.indexOf(',')+1,p.indexOf(')')));
				position = new Point(x,y);
				
				System.out.println("User: "+username);
				System.out.println("Type: "+type);
				System.out.println("ip: "+ip);
				System.out.println("Port: "+port);
				System.out.println("Pid: "+pid);
				System.out.println("Position: "+position);
				System.out.println("========================================");
				
				
				tizen.add(new HuhuIcetizen(g,username,type,ip,port,pid,position));
				//fetchString();
				//System.out.println(looks.gidB);
//				look = getto("gresources&uid="+g);
//				looks.gidB = look.substring(21, 30);
//				looks.gidS = look.substring(38, 47);
//				looks.gidH = look.substring(55, 64);
//				looks.gidW = look.substring(72, 81);
//				System.out.println(look);
//				look =(List<Map>)this.parser.parse(getto("gresources&uid="+g), this.containerFactory);
//				System.out.println(look.size());
				//System.out.println("Look: "+(String)((Map)look.get(0).get("B")).toString());
//				looks.gidB = (String)(look.get("data").toString().substring(21, 30));
//				
//				looks.gidS = (String)((Map)look.get("data")).get(0).toString();
//				looks.gidH = (String)((Map)look.get("data")).get("H");
//				looks.gidW = (String)((Map)look.get("data")).get("W");
			
//				if(look.get("status").toString().equals("0")){
//					alien.add(new HuhuIcetizen());
//				}else{
//					tizen.add(new HuhuIcetizen());
//				}
			}

			//action = (Map)this.parser.parse(getto("actions&from="+time), this.containerFactory);
			
			

//			this.uid = Integer.parseInt(jsonData.get("uid").toString());
//			this.accessToken = jsonData.get("access_token").toString();

			
			//Thread.sleep(1000);
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		

	}
	//}
	public String getto(String adder){
		try {
			
			myURL = new URL("http://iceworld.sls-atl.com/api/&cmd="+adder);
			URLConnection yc = myURL.openConnection();
			BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine;
			response = "";

			while ((inputLine = in.readLine()) != null) {
				response += inputLine+"\n";
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;
	}
	
	
	public static void main (String[]args){
		Fetching a = new Fetching();
		Thread b = new Thread(a);
		b.start();
		//System.out.println(a.weather);
	}
	

}
